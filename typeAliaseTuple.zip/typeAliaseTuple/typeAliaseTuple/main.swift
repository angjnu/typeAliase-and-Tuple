//
//  main.swift
//  typeAliaseTuple
//
//  Created by anil kumar giri on 21/02/16.
//  Copyright © 2016 AKG. All rights reserved.
//

import Foundation
// typeAliase example
typealias x=UInt8
var p:x = 20
print(p)

// Tuple example
 let x1 = (500,"hello")
print(x1)
//access elements by indexe
print("The first element's value is \(x1.0) and second element's value is \(x1.1)")


// Assignement of tuple in another tuple using var or constants
 var (t,l)=x1
print(t)
print(l)
// you can access that value you are interested in and ignore you are not interested in.
var (w,_)=x1
print(w)



